#!/bin/bash
#
# sui-camera V0.36
# suiFlightServer V1.4.4
#
# Zip a directory name update with the following files:
#    update.sh   <--- this file is here
#    sui-camera
#    suiFlightServer/__init__.py
#    suiFlightServer/image.py
#    suiFlightServer/imagedb.py
#    suiFlightServer/uploader.py
#    suiFlightServer/webServer.py
#
# Push the file to the Companion Computer
#    scp update.zip user@10.42.0.1:/home/user/Downloads/
#
# Make the restful api call to process the update
#    curl -d '{}' http://10.42.0.1:8080/sui/cc
#
#
systemctl restart suiFlightServer
exit 0