#!/usr/bin/env python
from __future__ import print_function
import os
import sys
import time

''' Our python files '''
import ParamUpdater


def main(paramFileName):
    version = '0.1'

    startTime = time.time()    
        
    os.system('systemctl stop sui-camera')    
      
    #check for parameter file
    try:
        if paramFileName is None:
            downloads_path = "./" 
            paramFileName = ParamUpdater.getParamFileName(downloads_path)
    except Exception as e:
        print(e)
     
    #if param file is found, try to upload it
    param1StartTime = time.time()
    if paramFileName is not None:
        try:
            ParamUpdater.updateParams(paramFileName)
        except Exception as e:
            print(e)
    totalParam1Time = (time.time() - param1StartTime)
           
    time.sleep(10)
            
    #if param file is found, try to upload it again
    #This will handle any parameters that are only revealed after a "parent parameter" is set (E.G. Batt_monitor reveals other parameters)
    param2StartTime = time.time()
    if paramFileName is not None:
        try:
            ParamUpdater.updateParams(paramFileName)
        except Exception as e:
            print(e)
    totalParam2Time = (time.time() - param2StartTime)

          
    totalTime = (time.time() - startTime)
    print("\n\n\n")
    print("Automatic Setup took " + str(totalTime) + "s")
    print("Automatic Setup Params 1 " + str(totalParam1Time) + "s")
    print("Automatic Setup Params 2 " + str(totalParam2Time) + "s")


if __name__ == '__main__':
    main(sys.argv[1])


