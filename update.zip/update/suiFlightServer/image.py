#!/usr/bin/env python
"""
image.py
Provides Image
"""

import sqlite3
import os
import shutil

senteraSnapshotPath = '/home/sentera/snapshots/'


table_name = 'image'
table_def = 'id INTEGER PRIMARY KEY, time INTEGER, lat INTEGER, lon INTEGER, pitch INTEGER, roll INTEGER, yaw INTEGER, heading INTEGER, alt INTEGER, size INTEGER, path TEXT COLLATE NOCASE'

table_old = 'oldfiles'
def_old = 'id INTEGER PRIMARY KEY, path TEXT COLLATE NOCASE, size INTEGER, flightID INTEGER, UNIQUE(path)'

table_flights = 'flights'
def_flights = 'id INTEGER PRIMARY KEY, flightID INTEGER, missionID TEXT COLLATE NOCASE, camType INTEGER, time INTEGER, UNIQUE(flightID)'

table_unknown = 'unknownFiles'
def_unknown = 'id INTEGER PRIMARY KEY, path TEXT COLLATE NOCASE, UNIQUE(path)'


class Image(object):
    """ An Image object has (id, time, lat, lon, pitch, roll, yaw, heading, alt, size, path) """

    def __init__(self, id=None, time=None, lat=None, lon=None, pitch=None, roll=None, yaw=None, heading=None, alt=None, size=None, path=None):
        self.id =   id
        self.time = time
        self.lat =  lat
        self.lon =  lon
        self.pitch= pitch
        self.roll = roll 
        self.yaw = yaw 
        self.heading = heading
        self.alt = alt
        self.size = size
        self.path = path

    def __str__(self):
        hasdata = False
        r = 'Image('
        if self.id is not None:
            r += 'id=' + str(self.id)
            hasdata = True
        if self.time is not None:
            if hasdata:
                r += ', '
            r += 'time=' + str(self.time)
            hasdata = True
        if self.lat is not None:
            if hasdata:
                r += ', '
            r += 'lat=' + str(self.lat)
            hasdata = True
        if self.lon is not None:
            if hasdata:
                r += ', '
            r += 'lon=' + str(self.lon)
            hasdata = True
        if self.pitch is not None:
            if hasdata:
                r += ', '
            r += 'pitch=' + str(self.pitch)
            hasdata = True
        if self.roll is not None:
            if hasdata:
                r += ', '
            r += 'roll=' + str(self.roll)
            hasdata = True
        if self.yaw is not None:
            if hasdata:
                r += ', '
            r += 'yaw=' + str(self.yaw)
            hasdata = True
        if self.heading is not None:
            if hasdata:
                r += ', '
            r += 'heading=' + str(self.heading)
            hasdata = True
        if self.alt is not None:
            if hasdata:
                r += ', '
            r += 'alt=' + str(self.alt)
            hasdata = True
        if self.size is not None:
            if hasdata:
                r += ', '
            r += 'size=' + str(self.size)
            hasdata = True
        if self.path is not None:
            if hasdata:
                r += ', '
            r += 'path="' + str(self.path) + '"'
        r += u')'
        return r

    def insert(self, db):
        """ insert this object into the database """
        rowid = None
        try:
            sql = 'INSERT INTO ' + table_name + '(time, lat, lon, pitch, roll, yaw, heading, alt, size, path) VALUES(?,?,?,?,?,?,?)'
            print sql
            cur = db.cursor()
            cur.execute(sql, (self.time, self.lat, self.lon, self.pitch, self.roll, self.yaw, self.heading, self.alt, self.size, self.path))
            db.commit()
            rowid = self.id = cur.lastrowid
        except sqlite3.Error, e:
            print e
            # raise e
        finally:
            pass
        return rowid

    def update(self, db, changes):
        """ update the database with with these changes to an image """
        try:
            sql = 'UPDATE ' + table_name + ' SET '
            values = []
            need_comma = False
            for k in changes:
                if need_comma:
                    sql += ','
                else:
                    need_comma = True
                sql += k + '=?'
                values.append(changes[k])
            sql += ' WHERE id=?'
            values.append(self.id)
            print sql, values
            cur = db.cursor()
            cur.execute(sql, values)
            db.commit()
            rowcount = cur.rowcount
            cur.close()
        except sqlite3.Error, e:
            print e
            rowcount = -1
            # raise e
        finally:
            pass
        return rowcount

    def fetch(self, db):
        """ fetch the object associated with self.id from the database """
        fetched = False
        try:
            sql = 'SELECT time, lat, lon, pitch, roll, yaw, heading, alt, size, path FROM ' + table_name + ' WHERE id=?'
            print sql
            cur = db.cursor()
            cur.execute(sql, (self.id,))
            row = cur.fetchone()
            if row is not None:
                self.time = row[0]
                self.lat = row[1]
                self.lon = row[2]
                self.pitch = row[3]
                self.roll = row[4]
                self.yaw = row[5]
                self.heading = row[6]
                self.alt = row[7]
                self.size = row[8]
                self.path = row[9]
                fetched = True
        except sqlite3.Error, e:
            print e
            # raise e
        finally:
            pass
        return fetched

    def delete(self, db):
        """ delete the object associated with self.id from the database """
        try:
            sql = 'DELETE FROM ' + table_name + ' WHERE id=?'
            print sql
            cur = db.cursor()
            cur.execute(sql, (self.id,))
            db.commit()
            rowcount = cur.rowcount
        except sqlite3.Error, e:
            print e
            rowcount = -1
            # raise e
        finally:
            pass
        return rowcount


def make_image(kwargs):
    my_id = None
    my_time = None
    my_lat = None
    my_lon = None
    my_pitch = None
    my_roll = None
    my_yaw = None
    my_heading = None
    my_alt = None
    my_size = None
    my_path = None
    if 'id' in kwargs:
        my_id = kwargs['id']
    if 'time' in kwargs:
        my_time = kwargs['time']
    if 'lat' in kwargs:
        my_lat = kwargs['lat']
    if 'lon' in kwargs:
        my_lon = kwargs['lon']
    if 'pitch' in kwargs:
        my_pitch = kwargs['pitch']
    if 'roll' in kwargs:
        my_roll = kwargs['roll']
    if 'yaw' in kwargs:
        my_yaw = kwargs['yaw']
    if 'heading' in kwargs:
        my_heading = kwargs['heading']
    if 'alt' in kwargs:
        my_alt = kwargs['alt']
    if 'size' in kwargs:
        my_size = kwargs['size']
    if 'path' in kwargs:
        my_path = kwargs['path']
    return Image(my_id, my_time, my_lat, my_lon, my_pitch, my_roll, my_yaw, my_heading, my_alt, my_size, my_path)


def fetchlist(db):
    """ Fetch a list of images from the database """
    imglist = []
    if db is not None:
        sql = 'SELECT t1.id, t1.time, t1.lat, t1.lon, t1.pitch, t1.roll, t1.yaw, t1.heading, t1.alt, t1.size, t1.path FROM ' + table_name + ' t1 WHERE t1.path IS NOT NULL AND path != "" AND NOT EXISTS (SELECT t2.path FROM ' + table_old + ' t2 WHERE t1.path=t2.path) ORDER BY id'
        print sql
        cur = db.cursor()
        for row in cur.execute(sql):
            img = Image(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10])
            imglist.append(img)
    return imglist
    
    
def fetchFIDlist(db):
    """ Fetch a list of flightIDs from the oldfiles table """
    fIDlist = []
    if db is not None:
        sql = 'SELECT DISTINCT flightID FROM ' + table_old + ' ORDER BY flightID'
        print sql
        cur = db.cursor()
        for ID in cur.execute(sql):
            sql1 = 'SELECT COUNT(*) FROM ' + table_old + ' WHERE flightID = ?;'
            print sql1
            cur1 = db.cursor()
            cur1.execute(sql1, (ID))
            count = cur1.fetchone()
                    
            sql2 = 'SELECT missionID, time FROM ' + table_flights + ' WHERE flightID = ?;'
            print sql2
            cur2 = db.cursor()
            cur2.execute(sql2, (ID))
            flightData = cur2.fetchone()
            
            fID = ID[0]
            imageCount = count[0]
            mID= flightData[0]
            Time = flightData[1]
            fIDlist.append({'FlightID' : fID, 'MissionID' : mID, 'Time' : Time, 'Images' : imageCount})
    return fIDlist
    
    
    
def fetchFIDlistMissionID(db, missionID):
    """ Fetch a list of flightIDs from the oldfiles table """
    fIDlist = []
    if db is not None:
        sql = 'SELECT DISTINCT flightID FROM ' + table_flights + ' WHERE missionID = "' + missionID + '" ORDER BY flightID'
        print sql
        cur = db.cursor()
        for ID in cur.execute(sql):
            sql1 = 'SELECT COUNT(*) FROM ' + table_old + ' WHERE flightID = ?;'
            print sql1
            cur1 = db.cursor()
            cur1.execute(sql1, (ID))
            count = cur1.fetchone()
                    
            sql2 = 'SELECT missionID, time FROM ' + table_flights + ' WHERE flightID = ?;'
            print sql2
            cur2 = db.cursor()
            cur2.execute(sql2, (ID))
            flightData = cur2.fetchone()
            
            fID = ID[0]
            imageCount = count[0]
            mID= flightData[0]
            Time = flightData[1]
            fIDlist.append({'FlightID' : fID, 'MissionID' : mID, 'Time' : Time, 'Images' : imageCount})
    return fIDlist

    

def fetchIDlist(db, flightID):
    """ Fetch a list of images in the oldFiles table with the given flightID """
    idlist = []
    if db is not None:
    
        sql = 'SELECT camType FROM ' + table_flights + ' WHERE flightID = ' + str(flightID)
        print sql
        cur = db.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        camType = row[0]
        
        
        sql = 'SELECT id, size, path FROM ' + table_old + ' WHERE flightID = ' + str(flightID) + ' ORDER BY id'
        print sql
        cur = db.cursor()
        for row in cur.execute(sql):
            id = row[0]
            Size = row[1]
            Path = row[2]
            
            if(camType == 2):   # Survey3
                filename = Path.split('/')
                #print filename[len(filename)-1]
                Path = filename[len(filename)-1]
            if(camType == 5):   # Survey3
                filename = Path.split('/')
                #print filename[len(filename)-2]
                #print filename[len(filename)-1]
                #print(filename[len(filename)-2] + '/' + filename[len(filename)-1])
                Path = (filename[len(filename)-2] + '/' + filename[len(filename)-1])
                
            idlist.append({'ImageID' : id, 'Size' : Size, 'Path' : Path})
            
    return idlist
    

def fetchImagePath(db, ID):
    """ Fetch the path of the image in the oldFiles table with the given ID """
    idlist = []
    if db is not None:
        sql = 'SELECT path, flightID FROM ' + table_old + ' WHERE id = ' + str(ID)
        print sql
        cur = db.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        path = row[0]
        
    return(path)
    


    
def deleteflight(db, flightID):
    """ Delete all files and database entries of the images associated with the given flightID """
    count = -1
    try:
        if db is not None:
            try:
                sql = 'SELECT camType FROM ' + table_flights + ' WHERE flightID = ' + str(flightID)
                print sql
                cur = db.cursor()
                cur.execute(sql)
                row = cur.fetchone()
                camType = row[0]
            except:
                print("Could not find flight")
                raise
            
            if(camType == 2):
                try:
                    sql = 'SELECT path FROM ' + table_old + ' WHERE flightID = ' + str(flightID) + ' ORDER BY id'
                    print sql
                    cur = db.cursor()
                    for row in cur.execute(sql):
                        path = row[0]
                        try:
                            '''Delete the image file from the camera'''
                            os.remove(path)
                            '''Delete the image file from the database'''
                            sql_delete = 'DELETE FROM ' + table_old + ' WHERE path = ' + "'" + path + "'" 
                            print sql_delete
                            cur_delete = db.cursor()
                            cur_delete.execute(sql_delete)
                            count = count + 1
                        except:
                            raise
                    try:
                        sql_delete1 = 'DELETE FROM ' + table_flights + ' WHERE flightID = ' + str(flightID)
                        print sql_delete1
                        cur_delete1 = db.cursor()
                        cur_delete1.execute(sql_delete1)
                    except:
                        print 'error deleting from flights'
                        raise
                except:
                    count = -1
                    raise
            if(camType == 5):
                '''Look for photo with the given flightID, parse the path for session name, delete session folder'''
                try:
                    # Find number of images associated with given flightID
                    sql = 'SELECT COUNT(*) FROM ' + table_old + ' WHERE flightID = ' + str(flightID) 
                    cur = db.cursor()
                    cur.execute(sql)
                    row = cur.fetchone()
                    count = row[0]
                    print(str(count) + " Images Found")
                    # Find session name associated with given flightID
                    sql = 'SELECT path FROM ' + table_old + ' WHERE flightID = ' + str(flightID) + ' ORDER BY id'  
                    cur = db.cursor()
                    cur.execute(sql)
                    row = cur.fetchone()
                    path = row[0].split("/")
                    sessionPath = senteraSnapshotPath + path[0]
                    print("finding " + sessionPath)
                    if ~os.path.exists(senteraSnapshotPath):
                        print("Attempting to mount sentera")
                        os.system('mount -t cifs -o username=blake,password= //192.168.143.141/sdcard /home/sentera/')
                        print("Sentera mounted Successfully")
                    if os.path.exists(sessionPath):
                        print 'Sentera session exists'
                        try:
                            shutil.rmtree(sessionPath)
                            deleteSession = True
                        except OSError as e:
                            print("Error: %s - %s." % (e.filename, e.strerror))
                        except Exception as e: 
                            print(e)    
                        print (sessionPath + " Sucessfully Deleted")
                    elif os.path.exists(senteraSnapshotPath):
                        # Sentera properly mounted but session does not exist
                        print("Sentera session " + sessionPath + " does not exist")
                        deleteSession = True
                    if(deleteSession):
                        # Remove image entries from oldfiles table
                        sql_delete = 'DELETE FROM ' + table_old + ' WHERE flightID = ' + str(flightID)
                        print sql_delete
                        cur_delete = db.cursor()
                        cur_delete.execute(sql_delete)
                        # Remove flight data from oldfiles table
                        sql_delete = 'DELETE FROM ' + table_flights + ' WHERE flightID = ' + str(flightID)
                        print sql_delete
                        cur_delete = db.cursor()
                        cur_delete.execute(sql_delete)
                except Exception as e:
                    count = -1
                    print("Error: could not delete flight")
                    print(e)









                
                    
            if count is not -1:
                db.commit()
                
                
                
    except Exception as e:
        print(e)
    return count
    
    
    
    
    
    
    
    
    
    
    
    
    