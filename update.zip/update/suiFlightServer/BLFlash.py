from pymavlink import mavutil
import pymavlink
from datetime import datetime 
#import pymavlink
import time
import os
import sys
import glob     #dependency used to get list of files in download folder

def checkFlashStatus(autopilot):
    try:
        startTime = time.time()
        while((time.time() - startTime) < 1):
            try:
                msg = autopilot.recv_msg()
                if(msg.get_type() == 'COMMAND_ACK'):
                    if(msg.command == mavutil.mavlink.MAV_CMD_FLASH_BOOTLOADER):
                        print(str(msg.result))
                        return msg.result
            except:
                pass   
        print("MAV_CMD_FLASH_BOOTLOADER ACK was never seen")
    except Exception as e:
        print(e)
    return 'ERROR'
   
def findVehicleSysID(autopilot):
    Done = False
    try:
        # Ping to let the AP we are here
        autopilot.mav.ping_send(
                    time.time(), # Unix time
                    0, # Ping number
                    0, # Request ping of all systems
                    0 # Request ping of all components
                )
        startTime = time.time()        
        while(True):
            try:
                msg = autopilot.recv_msg()
                if(msg.get_type() == 'HEARTBEAT'):
                    if((msg.type == mavutil.mavlink.MAV_TYPE_FIXED_WING) or (msg.type == mavutil.mavlink.MAV_TYPE_QUADROTOR)):
                        return msg.get_srcSystem()
            except:
                pass
            if((time.time() - startTime) > 5):
                return 0
    except Exception as e:
        print(e)
        return 0

def establish_connection(baudrate): 
    try:
        #print('establish_connection')
        # Setup mavlink version and dialect
        os.environ["MAVLINK20"] = "0"
        mavutil.set_dialect("ardupilotmega")
        #print('dialect set')
        # Start mavlink connection
        autopilot = mavutil.mavlink_connection('/dev/ttymxc2',  baud=baudrate)
        #print('connection successful')
        
        stayAlive = True
        return autopilot
    except Exception as e:
        print(e)
        return 0

def flash_bootloader():
    #connect to pixhawk over mavlink
    #send message to flash bootloader
    baudrates = [115200, 1500000]
    try:
        for baudrate in baudrates:
            print('Attempting to connect using baudrate: ' + str(baudrate))
            try:
                # Start mavlink connection
                autopilot = establish_connection(baudrate)
                if(autopilot == 0):
                    print('ERROR AUTOPILOT FAILED TO CONNECT')
                else:
                    tries = 0
                    while(tries < 3):
                        tries += 1
                        target_system = findVehicleSysID(autopilot)
                        print("target_system = %d" %target_system)
                        if(target_system != 0):
                            break
                    if(target_system != 0):
                            break    
            except Exception as e:
                print e
                if(tries == 3):
                    return 1        
     
        print('Connection Established')
        if(target_system == 0):
            print("ERROR, could not find vehicle sysID")
            return 1
        
        stayAlive = True
        target_component = 1
        param_index = -1
        
        autopilot.mav.command_long_send(target_system,target_component,mavutil.mavlink.MAV_CMD_FLASH_BOOTLOADER,0, 0, 0, 0, 0, 290876, 0, 0)
        checkFlashStatus(autopilot)
        #reboot_autopilot(autopilot, target_system, target_component)
        
    except Exception as e:
        print(e)
        print('Caused an unhandled Exception')
        return 1
    
    return 0
    
if __name__ == '__main__':  #checks if this file is the main program
    print("starting bootloader flash")
    flash_bootloader()
    print("Finished bootloader flash")