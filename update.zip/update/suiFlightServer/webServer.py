#!/usr/bin/env python

import web
import jsonpickle
import os
import subprocess
import urllib2
import getpass  #dependency used to determine username for download folder location
import glob     #dependency used to get list of files in download folder
from zipfile import ZipFile, ZIP_DEFLATED #dependency used to unzip update archives and zip logs
from argparse import Namespace  #dependency used to pass arguments to uploader

''' Our python files '''
import imagedb
import image
import uploader

version = '1.5'

zipFCFilename = 'ardupilot.zip'
zipCCFilename = 'update.zip'
appDir = '/root/sui'
downloadDir = '/home/user/Downloads'
dataflashDir = '/root/sui/dataflashlogs/'
dataflashLog = '/tmp/log.zip'
zipPath = downloadDir + '/' + zipCCFilename
updatePath = downloadDir + '/update/update.sh'
updateLog = downloadDir + '/update.log'


USB_CONNECTED = False

#GPIOs used to connect the pixhawk2 cube
gpio121_Path = '/sys/class/gpio/gpio121'
gpio122_Path = '/sys/class/gpio/gpio122'

# List of ports to check for Linux
SERIAL_PORTS="/dev/serial/by-id/*_PX4_*,/dev/serial/by-id/usb-3D_Robotics*,/dev/serial/by-id/usb-The_Autopilot*,/dev/serial/by-id/usb-Bitcraze*,/dev/serial/by-id/pci-Bitcraze*,/dev/serial/by-id/usb-Gumstix*,"

urls = (
    '/',                                'Index',
    '/sui/list_of_images',              'GetList',
    '/sui/image/(\d+)',                 'HandleImage',
    '/sui/logs',                        'HandleCCLogs',
    '/sui/version',                     'HandleVersion',
    '/sui/cc',                          'HandleCC',
    '/sui/fc',                          'HandleFC',
    '/sui/settings/fc',                 'HandleUpdateInfoFC',
    '/sui/settings/cc',                 'HandleUpdateInfoCC',
    '/sui/flightids/(\d+)',             'GetFlightIDs',
    '/sui/allflightids',                'GetAllFlightIDs',
    '/sui/imageids/(\d+)',              'GetImageIDs',
    '/sui/deleteflight/(\d+)',          'DeleteFlight'
)

def connectUSB():
    global USB_CONNECTED
    try:
        if(USB_CONNECTED == True):
            return 1
        else:
            #Checks if GPIOs were previously set
            if not os.path.exists(gpio121_Path):
                os.system('echo 121 > /sys/class/gpio/export')
            if not os.path.exists(gpio122_Path):
                os.system('echo 122 > /sys/class/gpio/export')

            ##Configures GPIOs to allow Serial through USB connection to the pixhawk2 cube
            os.system('echo out > /sys/class/gpio/gpio121/direction')
            os.system('echo 1 > /sys/class/gpio/gpio121/value')

            os.system('echo out > /sys/class/gpio/gpio122/direction')
            os.system('echo 0 > /sys/class/gpio/gpio122/value')
            USB_CONNECTED = True
            return 1
    except Exception as e:
        print(e)
        return 0

class Index:
    def GET(self):
        web.header('Content-Type', 'text/plain')
        return 'Hello, from suiFlightServer ' + version + '\n'

class HandleVersion:
    def GET(self):
        s = os.system(appDir + '/sui-camera --version > v.txt')
        s = open('v.txt', 'r').read()
        os.remove('v.txt')
        v = s.split()
        camVersion = v[1]
        data = { 'suiFlightServer': version, 'sui-camera': camVersion }
        res = jsonpickle.encode(data, unpicklable=False) + '\n'
        web.header('Content-Type', 'application/json')
        web.header('Content-Length', len(res))
        return res

def getFirmware():
    """Returns a string containing the path to the latest firmware in downloads folder.
    Also unzips any .zip archives named ardupilot.zip"""
    #user = getpass.getuser()    // This code is run as "root" so this line returns "root" and not "user"
    downloads_path = '/home/' + 'user' + '/Downloads/'
    #downloads_path = '/home/user/Downloads/'
    # unzip ardupilot archive
    list_of_files = glob.glob(downloads_path + '*')
    for file in list_of_files:
        if file.lower() == downloads_path.lower() + "ardupilot.zip":
            zip_ref = ZipFile(file, 'r')
            zip_ref.extractall(downloads_path)
            zip_ref.close()
    # get latest firmware
    list_of_files = glob.glob(downloads_path + '*')
    list_of_firmware = [file for file in list_of_files if file.endswith(('.px4', '.apj'))]
    latest_firmware = max(list_of_firmware, key=os.path.getctime)
    # print latest_firmware
    return str(latest_firmware)

class HandleFC:
    def POST(self):
        
        #Checks if GPIOs were previously set
        if not os.path.exists(gpio121_Path):
            os.system('echo 121 > /sys/class/gpio/export')
        if not os.path.exists(gpio122_Path):
            os.system('echo 122 > /sys/class/gpio/export')

        ##Configures GPIOs to allow Serial through USB connection to the pixhawk2 cube
        os.system('echo out > /sys/class/gpio/gpio121/direction')
        os.system('echo 1 > /sys/class/gpio/gpio121/value')
    
        os.system('echo out > /sys/class/gpio/gpio122/direction')
        os.system('echo 0 > /sys/class/gpio/gpio122/value')
        
        
        #Checks if new firmware is present
        try:
            firmware = getFirmware()

            if firmware:
                try:
                    #Passes firmware update parameters to the uploader
                    args = Namespace(baud_bootloader = 115200,
                        baud_flightstack = '57600',
                        boot_delay = None,
                        firmware = firmware,
                        force = False,
                        port = '/dev/serial/by-id/*_PX4_*,/dev/serial/by-id/usb-3D_Robotics*,/dev/serial/by-id/usb-The_Autopilot*,/dev/serial/by-id/usb-Bitcraze*,/dev/serial/by-id/pci-Bitcraze*,/dev/serial/by-id/usb-Gumstix*,/dev/serial/by-id/usb-ArduPilot*',
                        baud_bootloader_flash = None,
                        target_system = None,
                        target_component = None,
                        source_system = 100,
                        source_component = 0
                        )

                    uploader.main(args)
                    
                    statusMsg = "200 Sucessfully Loaded " + firmware
                        
                except:
                    statusMsg = "500 " + "Failed to upload firmware " + firmware
            else:
                statusMsg = "500 " + "No Firmware Found"
        except:
            statusMsg = "500 " + "No Firmware Found"
        
        web.ctx.status = statusMsg

class HandleCC:
    def GET(self):
        web.header('Content-Type', 'text/plain')
        return readLog()

    def POST(self):
        writeLog('started')
        warning = 'zip file does not exist: ' + zipPath
        if os.path.exists(zipPath):
            subprocess.call(['unzip', '-o', zipPath, '-d', downloadDir])
            warning = 'update script does not exist: ' + updatePath
            if os.path.exists(updatePath):
                warning = ''
                subprocess.call(['bash', updatePath, ])
        if len(warning) > 0:
            writeLog('failed ' + warning)
            return web.internalerror(warning)
        else:
            writeLog('success')

class HandleUpdateInfoFC:
    def GET(self):
        data = {'dir': downloadDir, 'file': zipCCFilename, 'ardupilot': zipFCFilename, 'user': 'user', 'pass': 'sui4TheWin'}
        res = jsonpickle.encode(data, unpicklable=False) + '\n'
        web.header('Content-Type', 'application/json')
        web.header('Content-Length', len(res))
        return res
               
class HandleUpdateInfoCC:
    def GET(self):
        data = {'dir': downloadDir, 'file': zipCCFilename, 'ardupilot': zipCCFilename, 'user': 'user', 'pass': 'sui4TheWin'}
        res = jsonpickle.encode(data, unpicklable=False) + '\n'
        web.header('Content-Type', 'application/json')
        web.header('Content-Length', len(res))
        return res

class HandleOnlyCCLogs:
    def GET(self):
        zip = '/tmp/CC.tar.gz'
        suicameraLog = '/tmp/sui-camera.log'
        suiFlightServerLog ='/tmp/suiFlightServer.log'
        os.system('/bin/journalctl -u sui-camera > ' + suicameraLog)
        os.system('/bin/journalctl -u suiFlightServer > ' + suiFlightServerLog)
        os.system('tar cvzf ' + zip + ' ' + suicameraLog + ' ' + suiFlightServerLog)
        res = open(zip, 'r').read()
        web.header('Content-Type', 'text/plain')
        web.header('Content-Length', len(res))
        return res
        
class HandleCCLogs:
    def GET(self):
        try:
            #find 5 newest log files
            logs2Retrieve = []
            files = filter(os.path.isfile, glob.glob(dataflashDir + "*"))
            files.sort(key=os.path.getmtime)
            for x in files[-5:]:
                logs2Retrieve.append(x)
            #get CC logs
            suicameraLog = '/tmp/sui-camera.log'
            suiFlightServerLog ='/tmp/suiFlightServer.log'
            os.system('/bin/journalctl -u sui-camera > ' + suicameraLog)
            os.system('/bin/journalctl -u suiFlightServer > ' + suiFlightServerLog)
            logs2Retrieve.append(suicameraLog)
            logs2Retrieve.append(suiFlightServerLog)
            # printing the list of all files to be zipped 
            print('Following files will be zipped:') 
            for file_name in logs2Retrieve: 
                print(file_name)   
            # writing files to a zipfile 
            with ZipFile(dataflashLog,'w', ZIP_DEFLATED) as zip: 
                # writing each file one by one 
                for file in logs2Retrieve: 
                    file_name_only= file.split(os.sep)[-1]
                    zip.write(file, file_name_only)  
            res = open(dataflashLog, 'r').read()
            web.header('Content-Type', 'text/plain')
            web.header('Content-Length', len(res))
            return res
        except Exception as e:
            print(e)
            return web.internalerror('Error listing vehicle dataflash logs')   

'''Gets a list with the FlightID, Time, and number of images of each flight that is in the database'''      
class GetFlightIDs:
    # Get a list of all flightIDs that exist in the oldfiles table
    def GET(self, urlid):
        print('get flight ID\n')
        db = web.ctx.db
        print('checking for db\n')
        if db is not None:
            print('db exists\n')
            fID_list = image.fetchFIDlistMissionID(db, urlid)
            res = jsonpickle.encode(fID_list, unpicklable=False) + '\n'
            web.header('Content-Type', 'application/json')
            web.header('Content-Length', len(res))
            return res
        return web.internalerror('No access to the Database')
               
'''Gets a list with the FlightID, Time, and number of images of each flight that is in the database'''      
class GetAllFlightIDs:
    # Get a list of all flightIDs that exist in the oldfiles table
    def GET(self):
        print('get flight ID\n')
        db = web.ctx.db
        print('checking for db\n')
        if db is not None:
            print('db exists\n')
            fID_list = image.fetchFIDlist(db)
            res = jsonpickle.encode(fID_list, unpicklable=False) + '\n'
            web.header('Content-Type', 'application/json')
            web.header('Content-Length', len(res))
            return res
        return web.internalerror('No access to the Database')
                             
'''Gets a list of all imageIDs associated with the given flightID'''        
class GetImageIDs:
    # Get a list of all IDs in the oldfiles table with the given flightID
    def GET(self, urlid):
        db = web.ctx.db
        if db is not None:
            FlightID = int(urlid)
            id_list = image.fetchIDlist(db, FlightID)
            res = jsonpickle.encode(id_list, unpicklable=False) + '\n'
            web.header('Content-Type', 'application/json')
            web.header('Content-Length', len(res))
            return res
        return web.internalerror('No access to the Database')
        
'''Gets the image file with the given ID in the oldFiles table'''
class HandleImage:
    def GET(self, urlid):
        db = web.ctx.db
        if db is not None:
            id = int(urlid)
            path = image.fetchImagePath(db, id)
            if path is not None:
                web.header('Content-Type', 'images/jpeg')
                web.header('Content-Length', os.path.getsize(path))
                return open(path, "rb").read()     
            return web.notfound('metadata for ' + str(urlid) + ' not found')
        return web.internalerror('No access to the Database')

'''Deletes all files and database entries of the images associated with the given flightID'''       
class DeleteFlight:
    def GET(self, urlid):
        db = web.ctx.db
        if db is not None:
            FlightID = int(urlid)
            count = image.deleteflight(db, FlightID)
            if count is not -1:
                res = jsonpickle.encode(count, unpicklable=False) + '\n'
            else:
                return web.internalerror('Error Deleting Flight Data')
        else:
            return web.internalerror('No access to the Database')
        
        return res


dbi = imagedb.ImageDB()


def ctx_hook():
    web.ctx.db = dbi

def writeLog(msg):
    f = open(updateLog, 'w')
    f.write(msg)
    f.close()

def readLog():
    if os.path.exists(updateLog):
        f = open(updateLog, 'r')
        msg = f.read()
        f.close()
    else:
        msg = 'unknown\n'
    return msg

app = web.application(urls, globals())  # enables the functions 
app.add_processor(web.loadhook(ctx_hook)) # creates the Database

if __name__ == '__main__':  #checks if this file is the main program
    app.run()   #start an HTTP server on the port named in the first command line argument, or, if there is no argument, on port 8080.
