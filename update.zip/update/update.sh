#!/bin/bash
#
# sui-camera V0.36
# suiFlightServer V1.4.4
#
# Zip a directory name suiUpdate with the following files:
#    update.sh   <--- this file is here
#    sui-camera
#    suiFlightServer/__init__.py
#    suiFlightServer/image.py
#    suiFlightServer/imagedb.py
#    suiFlightServer/uploader.py
#    suiFlightServer/webServer.py
#
# Push the file to the Companion Computer
#    scp suiUpdate.zip user@10.42.0.1:/home/user/Downloads/
#
# Make the restful api call to process the update
#    curl -d '{}' http://10.42.0.1:8080/sui/cc
#
#
pip uninstall -y serial
pip install pyserial
SRCDIR='/home/user/Downloads/update'
DESTDIR='/root/sui'
# Stop processes we're going to update
systemctl stop sui-camera
# Update
CAMFILE="${SRCDIR}/sui-camera"
if [ -f ${CAMFILE} ]; then
	cp -f ${CAMFILE} ${DESTDIR}/ 
    chmod +x ${DESTDIR}/sui-camera
fi
SVRDIR="${SRCDIR}/suiFlightServer"
if [ -d ${SVRDIR} ]; then
	cp -f ${SVRDIR}/* ${DESTDIR}/suiFlightServer/ 
fi
VERFILE="${SRCDIR}/version"
cp -f ${VERFILE} ${DESTDIR}/ 
rm ${DESTDIR}/suiFlightServer/px_uploader.py
rm ${DESTDIR}/suiFlightServer/px_uploader.pyc
# Start the processes back up
systemctl start sui-camera
systemctl start suiFlightServer
exit 0